# skin.weatherclock
A Kodi skin designed to turn the media player into a weather clock.
