
from resources.lib.wslite import Main

if ( __name__ == "__main__" ):
    Main()
